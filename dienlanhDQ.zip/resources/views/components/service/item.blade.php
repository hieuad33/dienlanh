<div class="col-lg-3 col-md-6" data-aos="fade-up" data-aos-delay="300">
  <div class="card">
    <div class="card-img">
      <img src="assets/img/cargo-service.jpg" alt="mota" class="img-fluid">
    </div>
    <h3><a href="service-details/{{service->slug}}" class="stretched-link">{{service->name}}</a></h3>
    <p>{{service->description}}</p>
  </div>
</div>