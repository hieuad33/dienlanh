<?php return array (
  'categories.create' => 'App\\Http\\Livewire\\Categories\\Create',
  'categories.show' => 'App\\Http\\Livewire\\Categories\\Show',
  'categories.update' => 'App\\Http\\Livewire\\Categories\\Update',
  'contact.create' => 'App\\Http\\Livewire\\Contact\\Create',
  'posts.create' => 'App\\Http\\Livewire\\Posts\\Create',
  'posts.show' => 'App\\Http\\Livewire\\Posts\\Show',
);