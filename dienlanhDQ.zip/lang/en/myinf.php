<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */

    'title' => 'These credentials do not match our records.',
    'phone1' => 'The provided password is incorrect.',
    'phone2' => 'Too many login attempts. Please try again in :seconds seconds.',
    'address'=> 'Too many login attempts. Please try again in :seconds seconds.',
     'email'=> 'Too many login attempts. Please try again in :seconds seconds.',
      'description'=> 'Too many login attempts. Please try again in :seconds seconds.',
      'keywords'=> 'Too many login attempts. Please try again in :seconds seconds.',

];
